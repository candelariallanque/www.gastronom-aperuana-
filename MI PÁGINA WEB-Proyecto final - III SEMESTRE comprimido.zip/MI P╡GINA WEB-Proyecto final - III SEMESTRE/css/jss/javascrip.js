function mostrarDetalle(receta) {
    let mensaje = '';

    switch(receta) {
            case 'Chicharrón de chancho':
            mensaje = 'La pizza es un plato de origen italiano, consistente en un pan plano, normalmente de forma circular, que se cocina en el horno.';
            break;
          
            case 'Caldo de cordero':
            mensaje = 'El sushi es un plato de origen japonés basado en arroz sazonado con vinagre y complementado con pescado crudo, mariscos, vegetales, etc.';
            break;

            case 'Picante de cuy':
            mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break;

            case 'Caldo de cabeza de cordero':
                mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break; 

            case 'Cuy chactado':
            mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break;

            case 'Guiso de quinua':
            mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break;

            case 'Cebiche de trucha':
            mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break;

            case 'Charqui con olluquitos':
            mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break;

            case 'Mondongo o patasca':
            mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break;

            case 'Chupe verde':
            mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break;

            case 'Rocoto relleno':
            mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break;

            case 'Trucha frita':
            mensaje = 'Los tacos son un plato tradicional mexicano que consiste en una tortilla rellena de diferentes ingredientes como carne, pollo, pescado, vegetales, entre otros.';
            break;
            
               

               

        default:
            mensaje = 'Receta no encontrada.';
    }

    alert(mensaje);
}

document.getElementById('contactoForm').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Formulario enviado con éxito.');
});